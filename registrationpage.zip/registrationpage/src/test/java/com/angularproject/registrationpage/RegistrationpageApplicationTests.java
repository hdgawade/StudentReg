package com.angularproject.registrationpage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationpageApplicationTests {

	@Test
	void contextLoads() {
	}

}
